package com.example.musikmysql.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musikmysql.Model.DataModel;
import com.example.musikmysql.R;

import java.util.List;

public class AdapterData extends RecyclerView.Adapter<AdapterData.HolderData>{
    private Context ctx;
    private List<DataModel> listdata;

    public AdapterData(Context ctx, List<DataModel> listdata) {
        this.ctx = ctx;
        this.listdata = listdata;
    }

    @NonNull
    @Override
    public HolderData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item,parent,false);
        HolderData holder = new HolderData(layout);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HolderData holder, int position) {
        DataModel dm = listdata.get(position);
        holder.tvNo.setText(String.valueOf(dm.getNo()));
        holder.tvJudul.setText(dm.getJudul());
        holder.tvArtis.setText(dm.getArtis());
        holder.tvAlbum.setText(dm.getAlbum());

    }

    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public class HolderData extends RecyclerView.ViewHolder
    {
        TextView tvNo,tvJudul,tvArtis,tvAlbum;

        public HolderData(@NonNull View itemView) {
            super(itemView);

            tvNo = itemView.findViewById(R.id.tv_no);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvArtis = itemView.findViewById(R.id.tv_artis);
            tvAlbum = itemView.findViewById(R.id.tv_album);
        }
    }

}
